import { createSlice } from "@reduxjs/toolkit";
import tasks from "../../../sample_data.json";
import { v4 as uuid } from "uuid";
import { deleteDirectory } from "./directory";

const userTokenSlice = createSlice({
  name: "UserToken",
  initialState: {
    id: null,
    username: null,
  },

  reducers: {
    creatUserToken: (state, action) => {
      const id = action.payload.id;
      const userName = action.payload.username;
    },

    deleteUserToken: (state) => {
      state.id = null;
      state.username = null;
    },
  },
});
export const { creatUserToken, deleteUserToken } = userTokenSlice.actions;
export default userTokenSlice.reducer;
